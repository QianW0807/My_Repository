package com.scwang.smartrefresh.header.waterdrop;

/**
 * Created by xiayong on 2015/6/25.
 * 实心圆
 */
public class Circle {
    public float x;//圆x坐标
    public float y;//圆y坐标
    public float radius;//圆半径
    public int color;//圆的颜色
}